# sm64coopdx 1.5.1 -> PS3 (PSL1GHT) - estado do port

**Nada aqui foi compilado ou testado** (o ambiente onde isto foi escrito nao tem o ps3toolchain nem um PS3).
Os patches foram validados apenas com `patch --dry-run` no codigo original. Espere erros de compilacao e
ajustes de nomes de API do PSL1GHT: use o log remoto e me mande a saida do compilador para corrigirmos.

## O que existe nesta pasta

| Arquivo | Funcao | Estado |
|---|---|---|
| `src/pc/ps3/ps3_platform.*` | sysutil (sair pelo XMB), rede, IP local, **log por UDP** | escrito |
| `src/pc/ps3/ps3_smoketest.c` | teste de fumaca: video + log + IP | escrito |
| `src/pc/gfx/gfx_ps3.c` | janela/video/flip (WAPI) completo no essencial; **renderizador (RAPI) e esqueleto que so limpa a tela** | parcial |
| `src/pc/audio/audio_ps3.c` | libaudio + reamostragem 32 kHz -> 48 kHz | escrito |
| `src/pc/controller/controller_ps3.c` | DualShock 3, mapeamento fixo | escrito |
| `src/pc/network/socket/socket_ps3.*` | UDP **IPv4** (o `socket.c` original so usa IPv6) | escrito |
| `patches/0001..0003` | selecao de backend, lista de controles, include do socket | aplicam limpo |
| `Makefile.ps3` | alvo `smoke`; alvo `game` ainda e um TODO | esqueleto |

## Como aplicar

```
cd sm64coopdx-1.5.1
cp -r /caminho/sm64coopdx-ps3/src/pc/* src/pc/
for p in /caminho/sm64coopdx-ps3/patches/*.patch; do patch -p1 < $p; done
cp /caminho/sm64coopdx-ps3/Makefile.ps3 .
```

## Fase 1 - teste de fumaca (faca isto primeiro)

1. Instale o ps3toolchain e exporte `PS3DEV` e `PSL1GHT`.
2. No PC: `nc -ul 18194` (recebe o log). Compile com o IP do seu PC: `make -f Makefile.ps3 PS3_NETLOG_IP=<ip-do-pc> smoke`.
3. Gere o `.self` e rode com `ps3load` (ou PKG). **Sucesso** = tela azul-escura + linhas `[smoke] frame ...` no `nc`.
4. Se algo falhar, me mande a saida do compilador/linker. Os pontos mais provaveis de erro:
   nomes de campos em `audioPortParam` (`attrib`/`attr`), `closesocket`/`netClose`, `SO_NBIO`, headers `net/netctl.h`.

## Bloqueios conhecidos (o que ainda falta de verdade)

1. **Renderizador RSX.** O Fast3D gera shaders GLSL em tempo de execucao (`gfx_opengl.c`); o RSX nao compila shader
   em runtime. Precisa de um uber-shader pre-compilado (vertex + fragment com uniforms do combiner), layout de
   vertice, upload de textura (swizzle/pitch do RSX), blend, depth e scissor. E a maior etapa.
2. **Rede entre PS3 e PC (endianness).** `packet_write/packet_read` fazem `memcpy` cru (569 chamadas). PS3 e big-endian,
   PC e little-endian.
   - **PS3 <-> PS3 funciona sem mudar nada** (os dois sao big-endian). Comece por ai.
   - **PS3 <-> PC** exige converter na serializacao. Trocar o `memcpy` por swap quando `length` e 2/4/8 e **armadilha**:
     quebra strings de 4 bytes e structs (`Vec3f`, etc.). O correto e auditar as chamadas por tipo.
3. **Lua 5.3.** `lib/lua` so tem headers e binarios x86/ARM. Baixe o fonte do Lua 5.3 e compile para PPU.
4. **C++.** 4 arquivos precisam de C++ (`engine/lighting_engine.cpp`, `pc/rom_checker.cpp`, `pc/mods/mod_fs.cpp`,
   `pc/mods/mod_storage.cpp`); os 3 de Direct3D saem. O GCC do ps3toolchain e antigo para C++17.
5. **Assets / ROM (corrigido).** O coopdx 1.5.1 carrega os assets da ROM **em tempo de execucao** (`rom_assets.c` abre o
   arquivo; `rom_checker.cpp` procura `baserom.*.z64` na pasta de dados). Entao o PS3 nao precisa de PC para isso:
   o usuario coloca a propria ROM no HDD/USB do console e o jogo le de la. Falta adaptar o caminho (`fs_get_write_path`,
   `gRomFilename`) para `/dev_hdd0/game/<ID>/USRDIR/` e conferir o uso de `__attribute__((constructor))` no PPU
   (ha milhares de assets enfileirados assim na inicializacao). A ROM nunca entra no PKG. Um PC so e usado para desenvolver.
6. **Memoria.** 256 MB de RAM: planeje limite de texturas, pools fixos e meca o uso do Lua desde o inicio.

## Lista de exclusoes (arquivos que dependem de SDL/curl/etc.)

Substituidos: `gfx_sdl.*`, `gfx_opengl.c`, `audio_sdl.*`, `controller_sdl.*`, `controller_mouse.c`, `controller_keyboard.c`,
`socket.c`, `socket_linux.*`.
Ainda com referencias a SDL e que precisam de `#ifdef TARGET_PS3`: `platform.c`, `crash_handler.c`,
`controller_bind_mapping.c`, `djui/djui_panel_controls.c`, `djui/djui_lua_profiler.c`.
Cortar no primeiro corte: `update_checker.c` (curl), `discord/`, `mumble/`, `network/coopnet/` (libjuice).

## Multiplayer por IP (o modelo que voce pediu)

- **Entrar:** a tela `djui_panel_join_direct.c` ja pede IP e porta; `socket_ps3.c` so aceita IPv4 numerico.
- **Hospedar e mostrar o IP:** o gancho e `djui_panel_host_message.c` (`djui_panel_host_message_create`).
  Adicionar um `djui_text_create` com `ps3_get_local_ip()` e a porta (`configHostPort`, padrao `DEFAULT_PORT`).
  Isso mostra o IP **local**; pela internet o host precisa abrir a porta UDP no roteador e passar o IP publico.
- Salas pelo PSN/XMB nao existem para homebrew.

## Mapeamento do controle (fixo)

X=A, Quadrado=B, L2=Z, L1=L, R1=R, Start=Start, D-pad=D-pad, analogico esquerdo=stick, analogico direito=botoes C.

## Proximos passos sugeridos

1. Fase 1 (smoke test) funcionando no console.
2. Triangulo texturizado no RSX (uber-shader minimo).
3. Jogo base sem Lua e sem rede (stubs), lendo a ROM do HDD do PS3.
4. Lua; 5. rede PS3<->PS3 por IP; 6. endianness para PS3<->PC.
