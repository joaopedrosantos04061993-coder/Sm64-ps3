// Janela + renderizador PS3 (libgcm/RSX via PSL1GHT).
// STATUS: ESQUELETO, NAO COMPILADO/TESTADO.
//  - Window manager (WAPI): completo no essencial (video, flip com vsync, loop, tempo).
//  - Rendering API (RAPI): inicializa o RSX e limpa a tela. NAO desenha triangulos ainda.
//    O Fast3D gera shaders GLSL em tempo de execucao (gfx_opengl.c); o RSX nao tem compilador em
//    runtime, entao o proximo passo e um uber-shader pre-compilado + upload de texturas. Ver docs/PS3_PORT.md.
#ifdef TARGET_PS3
#ifndef UNUSED
#define UNUSED __attribute__((unused))
#endif
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <malloc.h>
#include <sysutil/video.h>
#include <rsx/gcm_sys.h>
#include <rsx/rsx.h>

#include "gfx_window_manager_api.h"
#include "gfx_rendering_api.h"
#include "pc/ps3/ps3_platform.h"

#define HOST_SIZE   (32 * 1024 * 1024)
#define CB_SIZE     (1 * 1024 * 1024)
#define NUM_BUFFERS 2

static gcmContextData *sCtx;
static u32 sWidth = 1280, sHeight = 720;
static u32 sPitch, sDepthPitch, sDepthOffset;
static u32 *sColor[NUM_BUFFERS];
static u32 sColorOffset[NUM_BUFFERS];
static void *sDepth;
static int sCur = 0;
static u32 sFlipId = 0;

static void set_render_target(int idx) {
    gcmSurface sf;
    memset(&sf, 0, sizeof(sf));
    sf.colorFormat = GCM_SURFACE_X8R8G8B8;
    sf.colorTarget = GCM_SURFACE_TARGET_0;
    sf.colorLocation[0] = GCM_LOCATION_RSX;
    sf.colorOffset[0] = sColorOffset[idx];
    sf.colorPitch[0] = sPitch;
    for (int i = 1; i < 4; i++) { sf.colorLocation[i] = GCM_LOCATION_RSX; sf.colorOffset[i] = 0; sf.colorPitch[i] = 64; }
    sf.depthFormat = GCM_SURFACE_ZETA_Z24S8;
    sf.depthLocation = GCM_LOCATION_RSX;
    sf.depthOffset = sDepthOffset;
    sf.depthPitch = sDepthPitch;
    sf.type = GCM_SURFACE_TYPE_LINEAR;
    sf.antiAlias = GCM_SURFACE_CENTER_1;
    sf.width = sWidth;
    sf.height = sHeight;
    sf.x = 0;
    sf.y = 0;
    rsxSetSurface(sCtx, &sf);
}

// ---------------- Window manager ----------------

static void wm_init(UNUSED const char *title) {
    ps3_platform_init();

    void *host = memalign(1024 * 1024, HOST_SIZE);
    rsxInit(&sCtx, CB_SIZE, HOST_SIZE, host);

    videoState state;
    videoGetState(0, 0, &state);
    videoResolution res;
    videoGetResolution(state.displayMode.resolution, &res);
    sWidth = res.width;
    sHeight = res.height;

    videoConfiguration vc;
    memset(&vc, 0, sizeof(vc));
    vc.resolution = state.displayMode.resolution;
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = sWidth * 4;
    videoConfigure(0, &vc, NULL, 0);
    videoGetState(0, 0, &state);

    gcmSetFlipMode(GCM_FLIP_VSYNC);

    sPitch = sWidth * 4;
    for (int i = 0; i < NUM_BUFFERS; i++) {
        sColor[i] = (u32 *)rsxMemalign(64, sPitch * sHeight);
        rsxAddressToOffset(sColor[i], &sColorOffset[i]);
        gcmSetDisplayBuffer(i, sColorOffset[i], sPitch, sWidth, sHeight);
    }
    sDepthPitch = sWidth * 4;
    sDepth = rsxMemalign(64, sDepthPitch * sHeight);
    rsxAddressToOffset(sDepth, &sDepthOffset);

    gcmResetFlipStatus();
    ps3_netlog("[gfx] RSX ok, %ux%u\n", sWidth, sHeight);
}

static void wm_set_keyboard_callbacks(UNUSED kb_callback_t d, UNUSED kb_callback_t u, UNUSED void (*a)(void),
                                      UNUSED void (*t)(char *), UNUSED void (*e)(char *, int)) {}
static void wm_set_scroll_callback(UNUSED void (*cb)(float, float)) {}

static void wm_main_loop(void (*run_one_game_iter)(void)) {
    while (!ps3_platform_exit_requested()) { run_one_game_iter(); }
}

static void wm_get_dimensions(uint32_t *w, uint32_t *h) { *w = sWidth; *h = sHeight; }
static void wm_handle_events(void) { ps3_platform_poll(); }
static bool wm_start_frame(void) { return true; }
static void wm_swap_buffers_begin(void) {}

static void wm_swap_buffers_end(void) {
    gcmSetFlip(sCtx, sCur);
    rsxFlushBuffer(sCtx);
    gcmSetWaitFlip(sCtx);
    // espera o flip anterior terminar
    while (gcmGetFlipStatus() != 0) { usleep(200); }
    gcmResetFlipStatus();
    sCur = (sCur + 1) % NUM_BUFFERS;
    sFlipId++;
}

static double wm_get_time(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec + (double)tv.tv_usec / 1e6;
}

static void wm_shutdown(void) { gcmSetWaitFlip(sCtx); rsxFinish(sCtx, 1); }
static void wm_start_text_input(void) {}
static void wm_stop_text_input(void) {}
static char *wm_get_clipboard_text(void) { return NULL; }
static void wm_set_clipboard_text(UNUSED const char *t) {}
static void wm_set_cursor_visible(UNUSED bool v) {}
static void wm_delay(unsigned int ms) { usleep(ms * 1000); }
static int wm_get_max_msaa(void) { return 0; }
static void wm_set_window_title(UNUSED const char *t) {}
static void wm_reset_window_title(void) {}
static bool wm_has_focus(void) { return true; }

struct GfxWindowManagerAPI gfx_ps3_wm_api = {
    .init = wm_init,
    .set_keyboard_callbacks = wm_set_keyboard_callbacks,
    .set_scroll_callback = wm_set_scroll_callback,
    .main_loop = wm_main_loop,
    .get_dimensions = wm_get_dimensions,
    .handle_events = wm_handle_events,
    .start_frame = wm_start_frame,
    .swap_buffers_begin = wm_swap_buffers_begin,
    .swap_buffers_end = wm_swap_buffers_end,
    .get_time = wm_get_time,
    .shutdown = wm_shutdown,
    .start_text_input = wm_start_text_input,
    .stop_text_input = wm_stop_text_input,
    .get_clipboard_text = wm_get_clipboard_text,
    .set_clipboard_text = wm_set_clipboard_text,
    .set_cursor_visible = wm_set_cursor_visible,
    .delay = wm_delay,
    .get_max_msaa = wm_get_max_msaa,
    .set_window_title = wm_set_window_title,
    .reset_window_title = wm_reset_window_title,
    .has_focus = wm_has_focus,
};

// ---------------- Rendering API (esqueleto) ----------------

struct ShaderProgram { int dummy; };
static struct ShaderProgram sDummyShader;
static uint32_t sNextTex = 1;

static bool r_z_is_from_0_to_1(void) { return true; }   // RSX: z em [0,1]. Confirmar ao implementar
static void r_unload_shader(UNUSED struct ShaderProgram *p) {}
static void r_load_shader(UNUSED struct ShaderProgram *p) {}
static struct ShaderProgram *r_create_and_load_new_shader(UNUSED struct ColorCombiner *cc) { return &sDummyShader; }
static struct ShaderProgram *r_lookup_shader(UNUSED struct ColorCombiner *cc) { return &sDummyShader; }
static void r_shader_get_info(UNUSED struct ShaderProgram *p, uint8_t *n, bool used[2]) { *n = 0; used[0] = used[1] = false; }
static uint32_t r_new_texture(void) { return sNextTex++; }
static void r_select_texture(UNUSED int tile, UNUSED uint32_t id) {}
static void r_upload_texture(UNUSED const uint8_t *rgba32, UNUSED int w, UNUSED int h) {} // TODO: copiar p/ rsxMemalign + gcmSetTexture
static void r_set_sampler_parameters(UNUSED int s, UNUSED bool lin, UNUSED uint32_t cms, UNUSED uint32_t cmt) {}
static void r_set_depth_test(UNUSED bool v) {}
static void r_set_depth_mask(UNUSED bool v) {}
static void r_set_zmode_decal(UNUSED bool v) {}
static void r_set_viewport(UNUSED int x, UNUSED int y, UNUSED int w, UNUSED int h) {}
static void r_set_scissor(UNUSED int x, UNUSED int y, UNUSED int w, UNUSED int h) {}
static void r_set_use_alpha(UNUSED bool v) {}
static void r_draw_triangles(UNUSED float vbo[], UNUSED size_t len, UNUSED size_t tris) {} // TODO: uber-shader + rsxDrawVertexArray
static void r_init(void) {}
static void r_on_resize(void) {}

static void r_start_frame(void) {
    set_render_target(sCur);
    rsxSetClearColor(sCtx, 0xFF202040);       // azul-escuro: se voce ve isso, o video funciona
    rsxSetClearDepthStencil(sCtx, 0xFFFFFF00);
    rsxClearSurface(sCtx, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A | GCM_CLEAR_S | GCM_CLEAR_Z);
}
static void r_end_frame(void) {}
static void r_finish_render(void) {}
static const char *r_get_name(void) { return "RSX (skeleton)"; }
static void r_shutdown(void) {}

struct GfxRenderingAPI gfx_ps3_api = {
    .z_is_from_0_to_1 = r_z_is_from_0_to_1,
    .unload_shader = r_unload_shader,
    .load_shader = r_load_shader,
    .create_and_load_new_shader = r_create_and_load_new_shader,
    .lookup_shader = r_lookup_shader,
    .shader_get_info = r_shader_get_info,
    .new_texture = r_new_texture,
    .select_texture = r_select_texture,
    .upload_texture = r_upload_texture,
    .set_sampler_parameters = r_set_sampler_parameters,
    .set_depth_test = r_set_depth_test,
    .set_depth_mask = r_set_depth_mask,
    .set_zmode_decal = r_set_zmode_decal,
    .set_viewport = r_set_viewport,
    .set_scissor = r_set_scissor,
    .set_use_alpha = r_set_use_alpha,
    .draw_triangles = r_draw_triangles,
    .init = r_init,
    .on_resize = r_on_resize,
    .start_frame = r_start_frame,
    .end_frame = r_end_frame,
    .finish_render = r_finish_render,
    .get_name = r_get_name,
    .shutdown = r_shutdown,
};
#endif // TARGET_PS3
