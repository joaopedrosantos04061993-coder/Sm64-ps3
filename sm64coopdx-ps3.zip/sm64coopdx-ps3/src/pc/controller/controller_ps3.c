// Controle DualShock 3 via libio do PSL1GHT. STATUS: NAO COMPILADO/TESTADO.
// Mapeamento fixo por enquanto (sem tela de bind): ver tabela em docs/PS3_PORT.md.
#ifndef UNUSED
#define UNUSED __attribute__((unused))
#endif
#include <string.h>
#include <io/pad.h>
#include <ultra64.h>

#include "controller_api.h"

#define PS3_PAD_PORT 0

static bool sInitOk = false;

static void controller_ps3_init(void) {
    if (ioPadInit(7) != 0) { return; }
    sInitOk = true;
}

// stick 0..255 (centro 128) -> -80..80, com zona morta
static s8 scale_stick(int v) {
    int c = v - 128;
    if (c > -16 && c < 16) { return 0; }
    c = (c * 80) / 127;
    if (c > 80) { c = 80; }
    if (c < -80) { c = -80; }
    return (s8)c;
}

static void controller_ps3_read(OSContPad *pad) {
    if (!sInitOk) { return; }

    padInfo info;
    if (ioPadGetInfo(&info) != 0 || !info.status[PS3_PAD_PORT]) { return; }

    padData d;
    memset(&d, 0, sizeof(d));
    ioPadGetData(PS3_PAD_PORT, &d);
    if (d.len == 0) { return; }

    u32 b = 0;
    if (d.BTN_CROSS)    { b |= A_BUTTON; }
    if (d.BTN_SQUARE)   { b |= B_BUTTON; }
    if (d.BTN_L2)       { b |= Z_TRIG; }
    if (d.BTN_R1)       { b |= R_TRIG; }
    if (d.BTN_L1)       { b |= L_TRIG; }
    if (d.BTN_START)    { b |= START_BUTTON; }
    if (d.BTN_UP)       { b |= U_JPAD; }
    if (d.BTN_DOWN)     { b |= D_JPAD; }
    if (d.BTN_LEFT)     { b |= L_JPAD; }
    if (d.BTN_RIGHT)    { b |= R_JPAD; }

    // analogico direito -> botoes C (camera)
    int rx = (int)d.ANA_R_H - 128;
    int ry = (int)d.ANA_R_V - 128;
    if (rx >  64) { b |= R_CBUTTONS; }
    if (rx < -64) { b |= L_CBUTTONS; }
    if (ry < -64) { b |= U_CBUTTONS; }
    if (ry >  64) { b |= D_CBUTTONS; }

    pad->button |= b;

    s8 sx = scale_stick(d.ANA_L_H);
    s8 sy = (s8)-scale_stick(d.ANA_L_V); // eixo Y do PS3 e invertido
    if (sx != 0 || sy != 0) {
        pad->stick_x = sx;
        pad->stick_y = sy;
    }
}

static u32 controller_ps3_rawkey(void) { return VK_INVALID; }

static void controller_ps3_shutdown(void) {
    if (sInitOk) { ioPadEnd(); sInitOk = false; }
}

struct ControllerAPI controller_ps3 = {
    .vkbase   = 0x2000,
    .init     = controller_ps3_init,
    .read     = controller_ps3_read,
    .rawkey   = controller_ps3_rawkey,
    .shutdown = controller_ps3_shutdown,
};
