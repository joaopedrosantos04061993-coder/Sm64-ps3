// Audio PS3 (libaudio do PSL1GHT). STATUS: NAO COMPILADO/TESTADO.
// O jogo gera s16 estereo a 32000 Hz; a saida do PS3 e float a 48000 Hz,
// entao reamostramos (interpolacao linear, razao 2/3) em uma thread alimentadora.
#include <stdint.h>
#include <string.h>
#include <audio/audio.h>
#include <sys/thread.h>
#include <sys/event_queue.h>

#include "audio_api.h"

#define RING_FRAMES 16384           // potencia de 2
#define RING_MASK   (RING_FRAMES - 1)
#define STEP_16_16  43691           // 65536 * 32000/48000

static int16_t sRing[RING_FRAMES * 2];
static volatile uint32_t sWr = 0, sRd = 0;   // em frames, crescem sempre (SPSC lock-free)
static uint32_t sFrac = 0;

static uint32_t sPort;
static audioPortConfig sCfg;
static sys_event_queue_t sQueue;
static uint64_t sQueueKey;
static sys_ppu_thread_t sThread;
static volatile int sRunning = 0;

static inline uint32_t ring_avail(void) { return sWr - sRd; }

static void feeder(void *arg) {
    (void)arg;
    while (sRunning) {
        sys_event_t ev;
        if (sysEventQueueReceive(sQueue, &ev, 20 * 1000) != 0) { continue; }

        uint64_t cur = *(uint64_t *)(uintptr_t)sCfg.readIndex;
        uint32_t blk = (uint32_t)((cur + 1) % sCfg.numBlocks);
        float *out = (float *)(uintptr_t)sCfg.audioDataStart
                   + sCfg.channelCount * AUDIO_BLOCK_SAMPLES * blk;

        for (int i = 0; i < AUDIO_BLOCK_SAMPLES; i++) {
            float l = 0.0f, r = 0.0f;
            if (ring_avail() >= 2) {
                const int16_t *a = &sRing[(sRd & RING_MASK) * 2];
                const int16_t *b = &sRing[((sRd + 1) & RING_MASK) * 2];
                float f = (float)sFrac / 65536.0f;
                l = ((float)a[0] + ((float)b[0] - (float)a[0]) * f) / 32768.0f;
                r = ((float)a[1] + ((float)b[1] - (float)a[1]) * f) / 32768.0f;
                sFrac += STEP_16_16;
                while (sFrac >= 65536) { sFrac -= 65536; sRd++; }
            }
            out[i * 2 + 0] = l;
            out[i * 2 + 1] = r;
        }
    }
    sysThreadExit(0);
}

static bool audio_ps3_init(void) {
    if (audioInit() != 0) { return false; }

    audioPortParam p;
    memset(&p, 0, sizeof(p));
    p.numChannels = AUDIO_PORT_2CH;
    p.numBlocks   = AUDIO_BLOCK_8;
    p.attrib      = 0;      // confira o nome do campo no seu audio.h ("attrib" ou "attr")
    p.level       = 1.0f;

    if (audioPortOpen(&p, &sPort) != 0) { return false; }
    audioGetPortConfig(sPort, &sCfg);

    audioCreateNotifyEventQueue(&sQueue, &sQueueKey);
    audioSetNotifyEventQueue(sQueueKey);
    sysEventQueueDrain(sQueue);

    if (audioPortStart(sPort) != 0) { return false; }

    sRunning = 1;
    sysThreadCreate(&sThread, feeder, NULL, 1000, 0x4000, THREAD_JOINABLE, "ps3_audio");
    return true;
}

static int audio_ps3_buffered(void) { return (int)ring_avail(); }
static int audio_ps3_get_desired_buffered(void) { return 1100; }

static void audio_ps3_play(const uint8_t *buf, size_t len) {
    if (ring_avail() > 6000) { return; }   // mesma politica do backend SDL
    uint32_t frames = (uint32_t)(len / 4);
    if (frames > RING_FRAMES - ring_avail()) { frames = RING_FRAMES - ring_avail(); }
    const int16_t *src = (const int16_t *)buf;   // s16 nativo (big-endian aqui)
    uint32_t w = sWr;
    for (uint32_t i = 0; i < frames; i++) {
        sRing[((w + i) & RING_MASK) * 2 + 0] = src[i * 2 + 0];
        sRing[((w + i) & RING_MASK) * 2 + 1] = src[i * 2 + 1];
    }
    __sync_synchronize();
    sWr = w + frames;
}

static void audio_ps3_shutdown(void) {
    if (!sRunning) { return; }
    sRunning = 0;
    u64 ret;
    sysThreadJoin(sThread, &ret);
    audioPortStop(sPort);
    audioPortClose(sPort);
    audioQuit();
}

struct AudioAPI audio_ps3 = {
    audio_ps3_init,
    audio_ps3_buffered,
    audio_ps3_get_desired_buffered,
    audio_ps3_play,
    audio_ps3_shutdown,
};
