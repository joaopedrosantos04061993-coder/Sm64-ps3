// TESTE DE FUMACA (fase 1): valida toolchain, ps3load, video (RSX), rede e log remoto,
// sem depender do resto do jogo. Se a tela ficar azul-escura e o log chegar no PC, o ambiente esta OK.
// STATUS: NAO COMPILADO/TESTADO.
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "gfx/gfx_window_manager_api.h"
#include "gfx/gfx_rendering_api.h"
#include "ps3/ps3_platform.h"

extern struct GfxWindowManagerAPI gfx_ps3_wm_api;
extern struct GfxRenderingAPI gfx_ps3_api;

static int sFrames = 0;
static void one_frame(void) {
    gfx_ps3_wm_api.handle_events();
    gfx_ps3_api.start_frame();      // limpa a tela (azul-escuro)
    gfx_ps3_api.end_frame();
    gfx_ps3_wm_api.swap_buffers_end();
    if ((++sFrames % 120) == 0) {
        ps3_netlog("[smoke] frame %d, ip local %s\n", sFrames, ps3_get_local_ip());
    }
}

int main(void) {
    gfx_ps3_wm_api.init("smoke");   // inicia plataforma + RSX
    gfx_ps3_wm_api.main_loop(one_frame);
    gfx_ps3_wm_api.shutdown();
    return 0;
}
