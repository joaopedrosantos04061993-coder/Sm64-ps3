#ifndef PS3_PLATFORM_H
#define PS3_PLATFORM_H
// Camada de plataforma do PS3 (PSL1GHT). STATUS: NAO COMPILADO/TESTADO.
#include <stdbool.h>

void ps3_platform_init(void);          // sysutil, rede, log remoto
void ps3_platform_poll(void);          // processa eventos do XMB (sair, etc.)
bool ps3_platform_exit_requested(void);
const char *ps3_get_local_ip(void);    // IP local para mostrar na tela de host
void ps3_netlog(const char *fmt, ...); // printf por UDP para o PC (no PC: nc -ul 18194)

// IP do seu PC que recebe o log. Defina no build: -DPS3_NETLOG_IP='"192.168.0.10"'
#ifndef PS3_NETLOG_IP
#define PS3_NETLOG_IP "192.168.0.10"
#endif
#define PS3_NETLOG_PORT 18194

#endif
