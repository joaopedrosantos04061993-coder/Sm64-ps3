// STATUS: NAO COMPILADO/TESTADO. Baseado nas APIs do PSL1GHT; confira nomes/headers na sua instalacao.
#include "ps3_platform.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/net.h>
#include <net/netctl.h>
#include <sysutil/sysutil.h>

#ifndef UNUSED
#define UNUSED __attribute__((unused))
#endif

static volatile bool sExitRequested = false;
static int sLogSock = -1;
static struct sockaddr_in sLogAddr;
static char sLocalIp[32] = "0.0.0.0";

static void sysutil_cb(u64 status, UNUSED u64 param, UNUSED void *usrdata) {
    if (status == SYSUTIL_EXIT_GAME) { sExitRequested = true; }
}

void ps3_netlog(const char *fmt, ...) {
    if (sLogSock < 0) { return; }
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n <= 0) { return; }
    if (n >= (int)sizeof(buf)) { n = sizeof(buf) - 1; }
    sendto(sLogSock, buf, n, 0, (struct sockaddr *)&sLogAddr, sizeof(sLogAddr));
}

void ps3_platform_init(void) {
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, sysutil_cb, NULL);

    netInitialize();
    netCtlInit();

    // IP local, para mostrar na tela de "Hospedar"
    union net_ctl_info info;
    if (netCtlGetInfo(NET_CTL_INFO_IP_ADDRESS, &info) == 0) {
        snprintf(sLocalIp, sizeof(sLocalIp), "%s", info.ip_address);
    }

    // Log remoto: a ferramenta de debug mais importante no hardware real
    sLogSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    memset(&sLogAddr, 0, sizeof(sLogAddr));
    sLogAddr.sin_family = AF_INET;
    sLogAddr.sin_port = htons(PS3_NETLOG_PORT);
    inet_pton(AF_INET, PS3_NETLOG_IP, &sLogAddr.sin_addr);
    ps3_netlog("[ps3] sm64coopdx PS3 iniciado, ip local %s\n", sLocalIp);
}

void ps3_platform_poll(void) { sysUtilCheckCallback(); }
bool ps3_platform_exit_requested(void) { return sExitRequested; }
const char *ps3_get_local_ip(void) { return sLocalIp; }
