# sm64coopdx-ps3 (WIP)

Overlay de port do sm64coopdx 1.5.1 para PS3 (PSL1GHT). **Nao compilado, nao testado.**
Leia `docs/PS3_PORT.md`. Comece pelo teste de fumaca (`make -f Makefile.ps3 smoke`).
Requer PS3 com HEN ou CFW. Nao inclui ROM; ela deve ser fornecida por voce e usada so no build de PC.
